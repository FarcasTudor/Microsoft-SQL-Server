create procedure removeTabel
as
begin

--delete a table
drop table Manager
print 'Tabelul Manager tocmai a fost sters!'
end
go




