create procedure addColumn
as
begin

alter table Manager
add AniExperienta int 
print 'Am adaugat coloana AniExperienta in tabelul Manager'
end
go

