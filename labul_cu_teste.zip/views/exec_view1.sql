create procedure exec_view1
as 
begin
	select * from View_1
end