CREATE VIEW View_1 AS
SELECT descriere, cantitate from Tipuri
GO